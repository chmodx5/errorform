<template>
  <v-card class="py-10 mb-10" color="primary" flat dark>
    <h2 class="font-weight-black text-h4 text-center">
      Medical Error Form | KNH
    </h2></v-card
  >
</template>
